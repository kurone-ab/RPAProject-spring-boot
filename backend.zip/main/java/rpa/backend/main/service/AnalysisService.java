package rpa.backend.main.service;

import java.util.List;

public interface AnalysisService {
    boolean allAnalysis(List<String> languageList);
}
