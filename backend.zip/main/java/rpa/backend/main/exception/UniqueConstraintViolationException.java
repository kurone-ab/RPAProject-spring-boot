package rpa.backend.main.exception;

public class UniqueConstraintViolationException extends RuntimeException{
}
