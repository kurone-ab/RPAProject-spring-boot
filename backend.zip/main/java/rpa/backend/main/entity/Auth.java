package rpa.backend.main.entity;

public enum Auth {
    NORMAL, ADMIN
}
